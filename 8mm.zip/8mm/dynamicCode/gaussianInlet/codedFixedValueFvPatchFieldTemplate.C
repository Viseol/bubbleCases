/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     | Website:  https://openfoam.org
    \\  /    A nd           | Copyright (C) YEAR OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

\*---------------------------------------------------------------------------*/

#include "codedFixedValueFvPatchFieldTemplate.H"
#include "addToRunTimeSelectionTable.H"
#include "fieldMapper.H"
#include "volFields.H"
#include "surfaceFields.H"
#include "read.H"

//{{{ begin codeInclude

//}}} end codeInclude


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

namespace Foam
{

// * * * * * * * * * * * * * * * Local Functions * * * * * * * * * * * * * * //

//{{{ begin localCode

//}}} end localCode


// * * * * * * * * * * * * * * * Global Functions  * * * * * * * * * * * * * //

extern "C"
{
    // dynamicCode:
    // SHA1 = 6eed043daeaac5ff8bd819db8986fedc96e8de83
    //
    // unique function name that can be checked if the correct library version
    // has been loaded
    void gaussianInlet_6eed043daeaac5ff8bd819db8986fedc96e8de83(bool load)
    {
        if (load)
        {
            // code that can be explicitly executed after loading
        }
        else
        {
            // code that can be explicitly executed before unloading
        }
    }
}

// * * * * * * * * * * * * * * Static Data Members * * * * * * * * * * * * * //

makeRemovablePatchTypeField
(
    fvPatchVectorField,
    gaussianInletFixedValueFvPatchVectorField
);


const char* const gaussianInletFixedValueFvPatchVectorField::SHA1sum =
    "6eed043daeaac5ff8bd819db8986fedc96e8de83";


// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

gaussianInletFixedValueFvPatchVectorField::
gaussianInletFixedValueFvPatchVectorField
(
    const fvPatch& p,
    const DimensionedField<vector, volMesh>& iF,
    const dictionary& dict
)
:
    fixedValueFvPatchField<vector>(p, iF, dict)
{
    if (false)
    {
        Info<<"construct gaussianInlet sha1: 6eed043daeaac5ff8bd819db8986fedc96e8de83"
            " from patch/dictionary\n";
    }
}


gaussianInletFixedValueFvPatchVectorField::
gaussianInletFixedValueFvPatchVectorField
(
    const gaussianInletFixedValueFvPatchVectorField& ptf,
    const fvPatch& p,
    const DimensionedField<vector, volMesh>& iF,
    const fieldMapper& mapper
)
:
    fixedValueFvPatchField<vector>(ptf, p, iF, mapper)
{
    if (false)
    {
        Info<<"construct gaussianInlet sha1: 6eed043daeaac5ff8bd819db8986fedc96e8de83"
            " from patch/DimensionedField/mapper\n";
    }
}


gaussianInletFixedValueFvPatchVectorField::
gaussianInletFixedValueFvPatchVectorField
(
    const gaussianInletFixedValueFvPatchVectorField& ptf,
    const DimensionedField<vector, volMesh>& iF
)
:
    fixedValueFvPatchField<vector>(ptf, iF)
{
    if (false)
    {
        Info<<"construct gaussianInlet sha1: 6eed043daeaac5ff8bd819db8986fedc96e8de83 "
            "as copy/DimensionedField\n";
    }
}


// * * * * * * * * * * * * * * * * Destructor  * * * * * * * * * * * * * * * //

gaussianInletFixedValueFvPatchVectorField::
~gaussianInletFixedValueFvPatchVectorField()
{
    if (false)
    {
        Info<<"destroy gaussianInlet sha1: 6eed043daeaac5ff8bd819db8986fedc96e8de83\n";
    }
}


// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

void gaussianInletFixedValueFvPatchVectorField::updateCoeffs()
{
    if (this->updated())
    {
        return;
    }

    if (false)
    {
        Info<<"updateCoeffs gaussianInlet sha1: 6eed043daeaac5ff8bd819db8986fedc96e8de83\n";
    }

//{{{ begin code
    #line 31 "/home/viseol/OpenFOAM/viseol-13/run/injection/withStep/гаусс/8mm3/0/U/inlet"

          const scalar t = this->db().time().value();

          scalar Umax = 0.725;      
          scalar t0   = 0.025;     
          scalar sigma = 0.006;   

          scalar Uin = Umax*exp(-pow((t - t0)/sigma,2));

          operator==(vector(0,0,Uin));
      
//}}} end code

    this->fixedValueFvPatchField<vector>::updateCoeffs();
}


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

} // End namespace Foam

// ************************************************************************* //

