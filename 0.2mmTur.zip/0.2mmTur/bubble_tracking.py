import os
import re
import csv
import numpy as np

CASE_DIR = "."
ALPHA_NAME = "alpha.water"
CV_FOLDER_NAME = "0.01"          
THRESHOLD = 0.5                  
AXIS = 2                         
Z_CUTOFF = 0.075                 
OUTPUT_CSV = "bubble_tracking.csv"

ANALYSIS_TMIN = 0.15
ANALYSIS_TMAX = 0.25


def is_time_dir(name):
    try:
        float(name)
        return True
    except ValueError:
        return False


def sorted_time_dirs(case_dir):
    times = [
        d for d in os.listdir(case_dir)
        if os.path.isdir(os.path.join(case_dir, d)) and is_time_dir(d)
    ]
    return sorted(times, key=lambda x: float(x))


def read_file_text(path):
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()


def read_internal_field_scalar(path):
    text = read_file_text(path)

    m_uniform = re.search(r"internalField\s+uniform\s+([^\s;]+)\s*;", text)
    if m_uniform:
        val = float(m_uniform.group(1))
        raise ValueError(f"{path}: found uniform scalar ({val}), expected nonuniform List<scalar>.")

    m = re.search(
        r"internalField\s+nonuniform\s+List<scalar>\s*(\d+)\s*\(\s*(.*?)\s*\)\s*;",
        text,
        re.S,
    )
    if not m:
        raise ValueError(f"{path}: couldn't read internalField scalar")

    n = int(m.group(1))
    body = m.group(2).strip().split()
    arr = np.array([float(x) for x in body], dtype=float)

    if len(arr) != n:
        raise ValueError(f"{path}: expected {n} scalar values, found {len(arr)}")

    return arr


def read_internal_field_vector(path):
    text = read_file_text(path)

    m_uniform = re.search(r"internalField\s+uniform\s+\(\s*([^\)]+)\)\s*;", text)
    if m_uniform:
        vals = [float(x) for x in m_uniform.group(1).split()]
        if len(vals) != 3:
            raise ValueError(f"{path}: incorrect uniform vector")
        raise ValueError(f"{path}: found uniform vector {vals}, expected nonuniform List<vector>.")

    m = re.search(
        r"internalField\s+nonuniform\s+List<vector>\s*(\d+)\s*\(\s*(.*?)\s*\)\s*;",
        text,
        re.S,
    )
    if not m:
        raise ValueError(f"{path}: couldn't read internalField vector")

    n = int(m.group(1))
    body = m.group(2)

    vec_strings = re.findall(r"\(\s*([^\(\)]+?)\s*\)", body)
    data = []

    for vs in vec_strings:
        vals = [float(x) for x in vs.split()]
        if len(vals) != 3:
            raise ValueError(f"{path}: incorrect vector: ({vs})")
        data.append(vals)

    arr = np.array(data, dtype=float)

    if arr.shape[0] != n:
        raise ValueError(f"{path}: expected {n} vector values, found {arr.shape[0]}")

    return arr


def load_cell_centres(case_dir, folder_name):
    c_path = os.path.join(case_dir, folder_name, "C")
    if not os.path.exists(c_path):
        raise FileNotFoundError(
            f"Did not find {c_path}\n"
            f"Run first:\n"
            f"foamPostProcess -func writeCellCentres -time {folder_name}"
        )
    return read_internal_field_vector(c_path)


def load_cell_volumes(case_dir, folder_name):
    v_path = os.path.join(case_dir, folder_name, "Vc")
    if not os.path.exists(v_path):
        raise FileNotFoundError(
            f"Did not find {v_path}\n"
            f"Run first:\n"
            f"foamPostProcess -func writeCellVolumes -time {folder_name}"
        )
    return read_internal_field_scalar(v_path)


def compute_bubble_metrics(C, V, alpha, axis=2, threshold=0.5, z_cutoff=None):
    if C.shape[0] != alpha.shape[0]:
        raise ValueError(f"Dimensions do not match: C={C.shape[0]}, alpha={alpha.shape[0]}")
    if V.shape[0] != alpha.shape[0]:
        raise ValueError(f"Dimensions do not match: V={V.shape[0]}, alpha={alpha.shape[0]}")

    coord = C[:, axis]

    if z_cutoff is not None:
        height_mask = coord < z_cutoff
    else:
        height_mask = np.ones_like(coord, dtype=bool)

    gas_fraction = 1.0 - alpha
    gas_fraction = np.clip(gas_fraction, 0.0, 1.0)

    gas_weight = gas_fraction * V * height_mask
    gas_sum = np.sum(gas_weight)

    if gas_sum <= 0:
        return np.nan, np.nan

    z_cm = np.sum(coord * gas_weight) / gas_sum

    tip_mask = (alpha < threshold) & height_mask
    if np.any(tip_mask):
        z_tip = np.max(coord[tip_mask])
    else:
        z_tip = np.nan

    return z_cm, z_tip


def compute_velocities(time, z):
    v = np.full_like(time, np.nan)
    dt = np.diff(time)
    dz = np.diff(z)
    v[1:] = dz / dt
    return v


def save_csv(filename, time, z_cm, z_tip, v_cm, v_tip, analysis_mask):
    with open(filename, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["time", "z_cm", "z_tip", "v_cm", "v_tip", "used_for_average"])
        for i in range(len(time)):
            writer.writerow([time[i], z_cm[i], z_tip[i], v_cm[i], v_tip[i], int(analysis_mask[i])])


def main():
    times = sorted_time_dirs(CASE_DIR)
    if not times:
        raise RuntimeError("Did not find time folders")

    C = load_cell_centres(CASE_DIR, CV_FOLDER_NAME)
    V = load_cell_volumes(CASE_DIR, CV_FOLDER_NAME)

    rows = []
    for t in times:
        alpha_path = os.path.join(CASE_DIR, t, ALPHA_NAME)
        if not os.path.exists(alpha_path):
            continue

        try:
            alpha = read_internal_field_scalar(alpha_path)
            z_cm, z_tip = compute_bubble_metrics(
                C, V, alpha,
                axis=AXIS,
                threshold=THRESHOLD,
                z_cutoff=Z_CUTOFF
            )
            rows.append([float(t), z_cm, z_tip])
        except Exception as e:
            print(f"[WARN] {t}: {e}")

    if len(rows) < 2:
        raise RuntimeError("There are not enough time steps to calculate velocity")

    rows = np.array(rows, dtype=float)
    time = rows[:, 0]
    z_cm = rows[:, 1]
    z_tip = rows[:, 2]

    v_cm = compute_velocities(time, z_cm)
    v_tip = compute_velocities(time, z_tip)

    analysis_mask = (
        (time >= ANALYSIS_TMIN) &
        (time <= ANALYSIS_TMAX) &
        np.isfinite(v_cm) &
        np.isfinite(v_tip) &
        np.isfinite(z_cm) &
        np.isfinite(z_tip)
    )

    save_csv(OUTPUT_CSV, time, z_cm, z_tip, v_cm, v_tip, analysis_mask)

    print(f"Result written to {OUTPUT_CSV}")
    print(f"Used cutoff: z < {Z_CUTOFF}")
    print(f"Manual analysis interval: {ANALYSIS_TMIN} to {ANALYSIS_TMAX} s")

    print("\nPoints used for averaging:")
    used_idx = np.where(analysis_mask)[0]
    for i in used_idx:
        print(
            f"t={time[i]:.5f}  z_cm={z_cm[i]:.6e}  z_tip={z_tip[i]:.6e}  "
            f"v_cm={v_cm[i]:.6e}  v_tip={v_tip[i]:.6e}"
        )

    used_v_cm = v_cm[analysis_mask]
    used_v_tip = v_tip[analysis_mask]

    if len(used_v_cm) > 0:
        print(f"\nTerminal velocity by center of mass: {np.mean(used_v_cm):.6e}")
    else:
        print("\nTerminal velocity by center of mass: not available")

    if len(used_v_tip) > 0:
        print(f"Terminal velocity by bubble tip:      {np.mean(used_v_tip):.6e}")
    else:
        print("Terminal velocity by bubble tip:      not available")
        
    with open("avarage_velocity.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow([np.mean(used_v_cm)])
        writer.writerow([np.mean(used_v_tip)])

if __name__ == "__main__":
    main()
