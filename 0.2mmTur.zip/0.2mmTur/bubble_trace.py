import os
import re
import csv
import numpy as np
import matplotlib.pyplot as plt

CASE_DIR = "."
ALPHA_NAME = "alpha.water"
CV_FOLDER_NAME = "0.01"          # папка, где лежат C и Vc
OUTPUT_CSV = "bubble_center_of_mass.csv"

# если нужно ограничить расчёт по высоте:
USE_CUTOFF = False
Z_CUTOFF = 0.075


def is_time_dir(name):
    try:
        float(name)
        return True
    except ValueError:
        return False


def sorted_time_dirs(case_dir):
    times = [
        d for d in os.listdir(case_dir)
        if os.path.isdir(os.path.join(case_dir, d)) and is_time_dir(d)
    ]
    return sorted(times, key=lambda x: float(x))


def read_file_text(path):
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()


def read_internal_field_scalar(path):
    text = read_file_text(path)

    m_uniform = re.search(r"internalField\s+uniform\s+([^\s;]+)\s*;", text)
    if m_uniform:
        val = float(m_uniform.group(1))
        raise ValueError(f"{path}: found uniform scalar ({val}), expected nonuniform List<scalar>.")

    m = re.search(
        r"internalField\s+nonuniform\s+List<scalar>\s*(\d+)\s*\(\s*(.*?)\s*\)\s*;",
        text,
        re.S,
    )
    if not m:
        raise ValueError(f"{path}: couldn't read internalField scalar")

    n = int(m.group(1))
    body = m.group(2).strip().split()
    arr = np.array([float(x) for x in body], dtype=float)

    if len(arr) != n:
        raise ValueError(f"{path}: expected {n} scalar values, found {len(arr)}")

    return arr


def read_internal_field_vector(path):
    text = read_file_text(path)

    m_uniform = re.search(r"internalField\s+uniform\s+\(\s*([^\)]+)\)\s*;", text)
    if m_uniform:
        vals = [float(x) for x in m_uniform.group(1).split()]
        if len(vals) != 3:
            raise ValueError(f"{path}: incorrect uniform vector")
        raise ValueError(f"{path}: found uniform vector {vals}, expected nonuniform List<vector>.")

    m = re.search(
        r"internalField\s+nonuniform\s+List<vector>\s*(\d+)\s*\(\s*(.*?)\s*\)\s*;",
        text,
        re.S,
    )
    if not m:
        raise ValueError(f"{path}: couldn't read internalField vector")

    n = int(m.group(1))
    body = m.group(2)

    vec_strings = re.findall(r"\(\s*([^\(\)]+?)\s*\)", body)
    data = []

    for vs in vec_strings:
        vals = [float(x) for x in vs.split()]
        if len(vals) != 3:
            raise ValueError(f"{path}: incorrect vector: ({vs})")
        data.append(vals)

    arr = np.array(data, dtype=float)

    if arr.shape[0] != n:
        raise ValueError(f"{path}: expected {n} vector values, found {arr.shape[0]}")

    return arr


def load_cell_centres(case_dir, folder_name):
    c_path = os.path.join(case_dir, folder_name, "C")
    if not os.path.exists(c_path):
        raise FileNotFoundError(
            f"Did not find {c_path}\n"
            f"Run first:\n"
            f"foamPostProcess -func writeCellCentres -time {folder_name}"
        )
    return read_internal_field_vector(c_path)


def load_cell_volumes(case_dir, folder_name):
    v_path = os.path.join(case_dir, folder_name, "Vc")
    if not os.path.exists(v_path):
        raise FileNotFoundError(
            f"Did not find {v_path}\n"
            f"Run first:\n"
            f"foamPostProcess -func writeCellVolumes -time {folder_name}"
        )
    return read_internal_field_scalar(v_path)


def compute_bubble_com(C, V, alpha, use_cutoff=False, z_cutoff=None):
    if C.shape[0] != alpha.shape[0]:
        raise ValueError(f"Dimensions do not match: C={C.shape[0]}, alpha={alpha.shape[0]}")
    if V.shape[0] != alpha.shape[0]:
        raise ValueError(f"Dimensions do not match: V={V.shape[0]}, alpha={alpha.shape[0]}")

    gas_fraction = 1.0 - alpha
    gas_fraction = np.clip(gas_fraction, 0.0, 1.0)

    if use_cutoff and z_cutoff is not None:
        mask = C[:, 2] < z_cutoff
    else:
        mask = np.ones(alpha.shape[0], dtype=bool)

    weights = gas_fraction * V * mask
    total_weight = np.sum(weights)

    if total_weight <= 0:
        return np.nan, np.nan, np.nan

    x_cm = np.sum(C[:, 0] * weights) / total_weight
    y_cm = np.sum(C[:, 1] * weights) / total_weight
    z_cm = np.sum(C[:, 2] * weights) / total_weight

    return x_cm, y_cm, z_cm


def save_csv(filename, time, x_cm, y_cm, z_cm):
    with open(filename, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["time", "x_cm", "y_cm", "z_cm"])
        for i in range(len(time)):
            writer.writerow([time[i], x_cm[i], y_cm[i], z_cm[i]])


def plot_one(time, values, ylabel, outname):
    plt.figure(figsize=(7, 5))
    plt.plot(time, values, marker="o", markersize=3)
    plt.xlabel("t, s")
    plt.ylabel(ylabel)
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(outname, dpi=300)
    plt.close()

def plot_xy_trajectory(x, y, outname):
    plt.figure(figsize=(6, 6))
    plt.plot(x, y, marker="o", markersize=3)

    # отметить старт и конец
    plt.scatter(x[0], y[0], label="start")
    plt.scatter(x[-1], y[-1], label="end")

    plt.xlabel("x, m")
    plt.ylabel("y, m")
    plt.title("Bubble trajectory (x-y plane)")
    plt.axis("equal")   # важно! чтобы не было искажений
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.savefig(outname, dpi=300)
    plt.close()


def main():
    times = sorted_time_dirs(CASE_DIR)
    if not times:
        raise RuntimeError("Did not find time folders")

    C = load_cell_centres(CASE_DIR, CV_FOLDER_NAME)
    V = load_cell_volumes(CASE_DIR, CV_FOLDER_NAME)

    rows = []
    for t in times:
        alpha_path = os.path.join(CASE_DIR, t, ALPHA_NAME)
        if not os.path.exists(alpha_path):
            continue

        try:
            alpha = read_internal_field_scalar(alpha_path)
            x_cm, y_cm, z_cm = compute_bubble_com(
                C, V, alpha,
                use_cutoff=USE_CUTOFF,
                z_cutoff=Z_CUTOFF
            )
            rows.append([float(t), x_cm, y_cm, z_cm])
        except Exception as e:
            print(f"[WARN] {t}: {e}")

    if len(rows) < 2:
        raise RuntimeError("There are not enough time steps")

    rows = np.array(rows, dtype=float)
    time = rows[:, 0]
    x_cm = rows[:, 1]
    y_cm = rows[:, 2]
    z_cm = rows[:, 3]

    save_csv(OUTPUT_CSV, time, x_cm, y_cm, z_cm)

    plot_one(time, x_cm, "x_cm, m", "x_vs_t.png")
    plot_one(time, y_cm, "y_cm, m", "y_vs_t.png")
    plot_one(time, z_cm, "z_cm, m", "z_vs_t.png")

    print(f"Result written to {OUTPUT_CSV}")
    print("Plots saved:")
    print("  x_vs_t.png")
    print("  y_vs_t.png")
    print("  z_vs_t.png")

    print("\nFirst points:")
    for i in range(min(10, len(time))):
        print(
            f"t={time[i]:.5f}  "
            f"x_cm={x_cm[i]:.6e}  "
            f"y_cm={y_cm[i]:.6e}  "
            f"z_cm={z_cm[i]:.6e}"
        )
        
    plot_xy_trajectory(x_cm, y_cm, "trajectory_xy.png")


if __name__ == "__main__":
    main()
